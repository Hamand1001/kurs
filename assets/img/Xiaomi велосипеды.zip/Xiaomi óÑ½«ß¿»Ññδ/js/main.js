$(function(){
    $('.bike-slider,.slider__items').slick({
        arrows:false,
        dots:true,
        fade:true, /* Чтобы картинки переключались плавно и без прокрутки. Эффект появления */
        autoplay:true, /* Автообновление картинок */
        autoplaySpeed:2000, /* Скорость обновления картинок  */

    })
})